package com.example.pract22_1

import android.annotation.SuppressLint
import android.app.DownloadManager.Request
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    lateinit var city: EditText
    lateinit var temper: TextView
    lateinit var davl: TextView
    lateinit var veter: TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        city = findViewById(R.id.city)
        temper = findViewById(R.id.temperatura)
        davl = findViewById(R.id.davl)
        veter = findViewById(R.id.vetr)
    }



    fun result(view: View) {
        if (city.text.toString().isNotEmpty() && city.text.toString() != null){
            var key = "af316ef71a783cea183dd9b74197b37c"
            var url="https://api.openweathermap.org/data/2.5/weather?q="+city.text.toString()+"&appid="+key+"&units=metric&lang=ru"
            var queue = Volley.newRequestQueue(this)
            var stringRequest = StringRequest(
                com.android.volley.Request.Method.GET,
                url,
                {
                    response->
                    val obj = JSONObject(response)
                    val temp = obj.getJSONObject("main")
                    var wind = obj.getJSONObject("wind")
                    var info1 = temp.getString("temp").toString()
                    var info2 = temp.getString("pressure").toString()
                    var info3 = wind.getString("speed").toString()
                    temper.text = "$info1 C"
                    davl.text = "$info2"
                    veter.text = "$info3 m/s"

                    Log.d("MyLog", "Response: ${temp.getString("temp")}")

                },
                {
                    Log.d("MyLog", "Volley error: $it")
                }
            )
            queue.add(stringRequest)



        }
        else
        {
            var sn = Snackbar.make(view,R.string.pods, Snackbar.LENGTH_LONG)
            sn.setActionTextColor(Color.RED).show()
        }
    }
}